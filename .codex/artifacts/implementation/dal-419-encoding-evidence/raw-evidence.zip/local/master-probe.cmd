@echo off
setlocal
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -startdir=none -arch=x64 -host_arch=x64
if errorlevel 1 exit /b 1
chcp
if defined CL exit /b 9
if defined _CL_ exit /b 9
cd /d D:\multica-builds\dal419-3103ab04
cl /nologo /std:c++17 /EHsc /MT /DWIN32 /DNOMINMAX /c /I source\dal-cpp master-probe.cpp /Fomaster-probe.obj
exit /b %ERRORLEVEL%
