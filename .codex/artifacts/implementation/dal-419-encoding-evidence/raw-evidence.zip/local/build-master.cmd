@echo off
setlocal
cd /d "D:\multica-builds\dal419-3103ab04\source"
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -startdir=none -arch=x64 -host_arch=x64
if errorlevel 1 exit /b 1
chcp
ver
where cl
cmake --version
if defined CL (echo Unexpected CL environment & exit /b 9)
if defined _CL_ (echo Unexpected _CL_ environment & exit /b 9)
set "CMAKE_BUILD_PARALLEL_LEVEL=6"
set "DAL_NUM_THREADS=4"
cmake -S . -B build/dal419 -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=D:/multica-builds/dal419-3103ab04/install -DMSVC_RUNTIME=static -DDAL_BUILD_PUBLIC=ON -DDAL_CPP_BUILD_TESTS=OFF -DDAL_PUBLIC_BUILD_TESTS=OFF -DDAL_CPP_BUILD_EXAMPLES=OFF -DDAL_BUILD_EXCEL=OFF -DDAL_BUILD_EXCEL_PORTABLE_TESTS=OFF
if errorlevel 1 exit /b 1
cmake --build build/dal419 --parallel 6
if errorlevel 1 exit /b 1
cmake --install build/dal419
if errorlevel 1 exit /b 1
exit /b 0
