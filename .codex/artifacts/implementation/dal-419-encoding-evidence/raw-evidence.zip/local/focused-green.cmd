@echo off
setlocal
cd /d "D:/multica-builds/dal419-3103ab04/source"
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -startdir=none -arch=x64 -host_arch=x64
if errorlevel 1 exit /b 1
chcp
if defined CL (echo Unexpected CL environment & exit /b 9)
if defined _CL_ (echo Unexpected _CL_ environment & exit /b 9)
set "CMAKE_BUILD_PARALLEL_LEVEL=6"
set "DAL_NUM_THREADS=4"
cmake -S D:/multica-builds/dal419-3103ab04/focused-source/focused -B D:/multica-builds/dal419-3103ab04/focused-green -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH=D:/multica-builds/dal419-3103ab04/install -DDAL419_SOURCE=D:/multica-builds/dal419-3103ab04/source
if errorlevel 1 exit /b 1
cmake --build D:/multica-builds/dal419-3103ab04/focused-green --parallel 4
if errorlevel 1 exit /b 1
D:/multica-builds/dal419-3103ab04/focused-green/debugger_tests.exe --gtest_output=xml:D:/multica-builds/dal419-3103ab04/focused-green.xml
if errorlevel 1 exit /b 1
D:/multica-builds/dal419-3103ab04/focused-green/compat.exe > D:/multica-builds/dal419-3103ab04/compat-green.bin
if errorlevel 1 exit /b 1
exit /b 0
