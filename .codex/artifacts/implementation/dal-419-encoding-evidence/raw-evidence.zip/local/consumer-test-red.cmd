@echo off
setlocal
cd /d "D:/multica-builds/dal419-3103ab04/source"
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -startdir=none -arch=x64 -host_arch=x64
if errorlevel 1 exit /b 1
chcp
if defined CL (echo Unexpected CL environment & exit /b 9)
if defined _CL_ (echo Unexpected _CL_ environment & exit /b 9)
set "CMAKE_BUILD_PARALLEL_LEVEL=6"
set "DAL_NUM_THREADS=4"
cmake --build D:/multica-builds/dal419-3103ab04/consumer-red --target dal_installed_consumer --parallel 1
if errorlevel 1 exit /b 1
exit /b 0
