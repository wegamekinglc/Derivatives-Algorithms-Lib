# CMake generated Testfile for 
# Source directory: D:/multica-builds/dal419-3103ab04/source/tests/installed-consumer
# Build directory: D:/multica-builds/dal419-3103ab04/consumer-red
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[dal_installed_consumer]=] "D:/multica-builds/dal419-3103ab04/consumer-red/dal_installed_consumer.exe")
set_tests_properties([=[dal_installed_consumer]=] PROPERTIES  _BACKTRACE_TRIPLES "D:/multica-builds/dal419-3103ab04/source/tests/installed-consumer/CMakeLists.txt;38;add_test;D:/multica-builds/dal419-3103ab04/source/tests/installed-consumer/CMakeLists.txt;0;")
add_test([=[dal_installed_aad_consumer]=] "D:/multica-builds/dal419-3103ab04/consumer-red/dal_installed_aad_consumer.exe")
set_tests_properties([=[dal_installed_aad_consumer]=] PROPERTIES  _BACKTRACE_TRIPLES "D:/multica-builds/dal419-3103ab04/source/tests/installed-consumer/CMakeLists.txt;39;add_test;D:/multica-builds/dal419-3103ab04/source/tests/installed-consumer/CMakeLists.txt;0;")
add_test([=[dal_installed_buffer_consumer]=] "D:/multica-builds/dal419-3103ab04/consumer-red/dal_installed_buffer_consumer.exe")
set_tests_properties([=[dal_installed_buffer_consumer]=] PROPERTIES  _BACKTRACE_TRIPLES "D:/multica-builds/dal419-3103ab04/source/tests/installed-consumer/CMakeLists.txt;40;add_test;D:/multica-builds/dal419-3103ab04/source/tests/installed-consumer/CMakeLists.txt;0;")
