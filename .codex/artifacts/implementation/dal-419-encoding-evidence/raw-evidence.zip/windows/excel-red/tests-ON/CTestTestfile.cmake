# CMake generated Testfile for 
# Source directory: D:/multica-builds/dal419-3103ab04/source/dal-excel
# Build directory: D:/multica-builds/dal419-3103ab04/excel-red/tests-ON
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
include("D:/multica-builds/dal419-3103ab04/excel-red/tests-ON/dal_excel_tests[1]_include.cmake")
