# CMake generated Testfile for 
# Source directory: D:/multica-builds/dal419-3103ab04/source/dal-cpp/externals/googletest
# Build directory: D:/multica-builds/dal419-3103ab04/excel-red/gtest-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("googletest")
