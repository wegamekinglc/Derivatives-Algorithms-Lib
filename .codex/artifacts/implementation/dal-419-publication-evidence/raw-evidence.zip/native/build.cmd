@echo off
setlocal
call :run > "D:/multica-builds/dal419-publication-38f7c283/build.log" 2>&1
set "DAL419_EXIT=%ERRORLEVEL%"
echo %DAL419_EXIT% > "D:/multica-builds/dal419-publication-38f7c283/build.exit.txt"
exit /b %DAL419_EXIT%
:run
if defined CL exit /b 90
if defined _CL_ exit /b 91
call "C:/Program Files/Microsoft Visual Studio/2022/Community/Common7/Tools/VsDevCmd.bat" -startdir=none -arch=x64 -host_arch=x64
if errorlevel 1 exit /b 92
if defined CL exit /b 93
if defined _CL_ exit /b 94
cd /d "D:/multica-builds/dal419-publication-38f7c283/source"
set "PATH=D:/multica-builds/dal419-tester-eb7d672c-696edf74/tools/cmake-4.2.3-windows-x86_64/bin;%PATH%"
chcp
ver
where cl
where cmake
cmake --version
ctest --version
"D:/multica-builds/dal418-eb7d672c679c-6372ede9/source/dal-python/.venv/Scripts/python.exe" "D:/multica-builds/dal419-publication-38f7c283/probe_environment.py"
if errorlevel 1 exit /b 95
set "CMAKE_BUILD_PARALLEL_LEVEL=6"
set "DAL_NUM_THREADS=4"
cmake -S . -B build/native -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=D:/multica-builds/dal419-publication-38f7c283/install -DMSVC_RUNTIME=static -DDAL_BUILD_PUBLIC=ON -DDAL_CPP_BUILD_TESTS=OFF -DDAL_CPP_BUILD_BENCHMARKS=OFF -DDAL_PUBLIC_BUILD_TESTS=OFF -DDAL_CPP_BUILD_EXAMPLES=OFF -DDAL_BUILD_EXCEL=OFF -DDAL_BUILD_EXCEL_PORTABLE_TESTS=OFF
if errorlevel 1 exit /b 1
cmake --build build/native --parallel 6
if errorlevel 1 exit /b 1
cmake --install build/native
if errorlevel 1 exit /b 1
exit /b 0
