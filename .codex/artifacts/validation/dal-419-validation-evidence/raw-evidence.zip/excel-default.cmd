@echo off
setlocal
call :run > "D:/multica-builds/dal419-tester-eb7d672c-696edf74/excel-default.log" 2>&1
set "DAL419_EXIT=%ERRORLEVEL%"
echo %DAL419_EXIT% > "D:/multica-builds/dal419-tester-eb7d672c-696edf74/excel-default.exit.txt"
exit /b %DAL419_EXIT%
:run
if defined CL exit /b 90
if defined _CL_ exit /b 91
call "C:/Program Files/Microsoft Visual Studio/2022/Community/Common7/Tools/VsDevCmd.bat" -startdir=none -arch=x64 -host_arch=x64
if errorlevel 1 exit /b 92
if defined CL exit /b 93
if defined _CL_ exit /b 94
cd /d "D:/multica-builds/dal419-tester-eb7d672c-696edf74/source"
set "PATH=D:/multica-builds/dal419-tester-eb7d672c-696edf74/tools/cmake-4.2.3-windows-x86_64/bin;%PATH%"
chcp
ver
where cl
where cmake
cmake --version
ctest --version
"D:/multica-builds/dal418-eb7d672c679c-6372ede9/source/dal-python/.venv/Scripts/python.exe" "D:/multica-builds/dal419-tester-eb7d672c-696edf74/probe_environment.py"
if errorlevel 1 exit /b 95
echo CL and _CL_ are undefined before and after VS setup
set "CMAKE_BUILD_PARALLEL_LEVEL=6"
set "DAL_NUM_THREADS=4"
cmake -DDAL_INSTALL_PREFIX=D:/multica-builds/dal419-tester-eb7d672c-696edf74/install -DDAL_OPTIONAL_EXCEL_BINARY_DIR=D:/multica-builds/dal419-tester-eb7d672c-696edf74/excel-default -P tests/optional-excel/windows-installed.cmake
if errorlevel 1 exit /b 1
exit /b 0
