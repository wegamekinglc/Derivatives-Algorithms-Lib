@echo off
setlocal
call :run > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-consumer-repro.log" 2>&1
set "DAL418_EXIT=%ERRORLEVEL%"
echo %DAL418_EXIT% > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-consumer-repro-exit.txt"
exit /b %DAL418_EXIT%
:run
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -startdir=none -arch=x64 -host_arch=x64
if errorlevel 1 exit /b 1
chcp
cmake --build "D:\multica-builds\dal418-eb7d672c679c-6372ede9\installed-consumer" --target dal_installed_consumer --parallel 1 > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-consumer-default-red.log" 2>&1
set "DAL418_DEFAULT_EXIT=%ERRORLEVEL%"
echo %DAL418_DEFAULT_EXIT% > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-consumer-default-exit.txt"
if "%DAL418_DEFAULT_EXIT%"=="0" exit /b 2
set "CL=/utf-8 %CL%"
cmake --build "D:\multica-builds\dal418-eb7d672c679c-6372ede9\installed-consumer" --parallel 3 > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-consumer-utf8-build.log" 2>&1
if errorlevel 1 exit /b 1
ctest --test-dir "D:\multica-builds\dal418-eb7d672c679c-6372ede9\installed-consumer" --output-on-failure -C Release > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-consumer-utf8-tests.log" 2>&1
if errorlevel 1 exit /b 1
exit /b 0
