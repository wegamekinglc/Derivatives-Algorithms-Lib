@echo off
call :run > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-python.log" 2>&1
set "DAL418_EXIT=%ERRORLEVEL%"
echo %DAL418_EXIT% > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-python-exit.txt"
exit /b %DAL418_EXIT%
:run
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -startdir=none -arch=x64 -host_arch=x64
if errorlevel 1 exit /b 1
cd /d "D:\multica-builds\dal418-eb7d672c679c-6372ede9\source"
set "DAL_NUM_THREADS=4"
set "PATH=D:\multica-builds\dal418-eb7d672c679c-6372ede9\source\dal-python\.venv\Scripts;%PATH%"
"D:\multica-builds\dal418-eb7d672c679c-6372ede9\source\dal-python\.venv\Scripts\python.exe" --version
build\Release-windows\dal-cpp\dal_cpp_tests.exe --gtest_filter="GSRRateOptionScriptTest.TestAccrualCompatibilitySnapshots:GSRRateOptionScriptTest.TestSubnormalAccrualUsesIndependentDecimalParserBoundary" --gtest_output="xml:D:/multica-builds/dal418-eb7d672c679c-6372ede9/windows-snapshots.xml"
if errorlevel 1 exit /b 1
cmake --preset Release-windows -DDAL_BUILD_PUBLIC=ON -DDAL_CPP_BUILD_EXAMPLES=ON -DDAL_CPP_BUILD_BENCHMARKS=OFF -DDAL_BUILD_PYTHON=ON "-DPython3_EXECUTABLE=D:\multica-builds\dal418-eb7d672c679c-6372ede9\source\dal-python\.venv\Scripts\python.exe"
if errorlevel 1 exit /b 1
cmake --build build\Release-windows --parallel 6
if errorlevel 1 exit /b 1
cmake --install build\Release-windows
if errorlevel 1 exit /b 1
ctest --test-dir build\Release-windows --verbose --output-on-failure --no-tests=error -C Release -R "^dal_python_pytest$"
if errorlevel 1 exit /b 1
exit /b 0
