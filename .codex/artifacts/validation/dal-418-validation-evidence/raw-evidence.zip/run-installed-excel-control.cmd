@echo off
setlocal
call :run > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-installed-excel-control.log" 2>&1
set "DAL418_EXIT=%ERRORLEVEL%"
echo %DAL418_EXIT% > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-installed-excel-control-exit.txt"
exit /b %DAL418_EXIT%
:run
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -startdir=none -arch=x64 -host_arch=x64
if errorlevel 1 exit /b 1
chcp
set "DAL_NUM_THREADS=4"
cmake --build "D:\multica-builds\dal418-eb7d672c679c-6372ede9\installed-excel\tests-ON" --target CMakeFiles/dal_excel_tests.dir/tests/test_curvature_request.cpp.obj --parallel 1 > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-installed-excel-narrow-red.log" 2>&1
set "DAL418_DEFAULT_EXIT=%ERRORLEVEL%"
echo %DAL418_DEFAULT_EXIT% > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-installed-excel-narrow-exit.txt"
if "%DAL418_DEFAULT_EXIT%"=="0" exit /b 2
set "CL=/utf-8 %CL%"
cmake --build "D:\multica-builds\dal418-eb7d672c679c-6372ede9\installed-excel\tests-ON" --parallel 6 > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-installed-excel-utf8-build.log" 2>&1
if errorlevel 1 exit /b 1
ctest --test-dir "D:\multica-builds\dal418-eb7d672c679c-6372ede9\installed-excel\tests-ON" -C Release --output-on-failure --no-tests=error --parallel 4 > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-installed-excel-utf8-tests.log" 2>&1
exit /b %ERRORLEVEL%
