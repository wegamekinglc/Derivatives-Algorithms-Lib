@echo off
call :run > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-standalone-python.log" 2>&1
set "DAL418_EXIT=%ERRORLEVEL%"
echo %DAL418_EXIT% > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-standalone-python-exit.txt"
exit /b %DAL418_EXIT%
:run
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -startdir=none -arch=x64 -host_arch=x64
if errorlevel 1 exit /b 1
cd /d "D:\multica-builds\dal418-eb7d672c679c-6372ede9\source"
set "DAL_NUM_THREADS=4"
set "PATH=D:\multica-builds\dal418-eb7d672c679c-6372ede9\source\dal-python\.venv\Scripts;%PATH%"
build\Release-windows\dal-cpp\dal_cpp_tests.exe --gtest_filter="GSRRateOptionScriptTest.TestAccrualCompatibilitySnapshots:GSRRateOptionScriptTest.TestSubnormalAccrualUsesIndependentDecimalParserBoundary" --gtest_output="xml:D:/multica-builds/dal418-eb7d672c679c-6372ede9/windows-snapshots.xml"
if errorlevel 1 exit /b 1
cmake -S dal-python -B "D:\multica-builds\dal418-eb7d672c679c-6372ede9\python-standalone" -G Ninja -DCMAKE_BUILD_TYPE=Release -DDAL_PYTHON_BUILD_TESTS=ON "-DDAL_INSTALL_PREFIX=D:\multica-builds\dal418-eb7d672c679c-6372ede9\source\build\stage\Release-windows" "-DPython3_EXECUTABLE=D:\multica-builds\dal418-eb7d672c679c-6372ede9\source\dal-python\.venv\Scripts\python.exe"
if errorlevel 1 exit /b 1
cmake --build "D:\multica-builds\dal418-eb7d672c679c-6372ede9\python-standalone" --parallel 6
if errorlevel 1 exit /b 1
ctest --test-dir "D:\multica-builds\dal418-eb7d672c679c-6372ede9\python-standalone" --verbose --output-on-failure --no-tests=error -C Release -R "^dal_python_pytest$"
if errorlevel 1 exit /b 1
cmake "-DDAL_INSTALL_PREFIX=D:\multica-builds\dal418-eb7d672c679c-6372ede9\source\build\stage\Release-windows" "-DDAL_CONSUMER_BINARY_DIR=D:\multica-builds\dal418-eb7d672c679c-6372ede9\installed-consumer" -DDAL_BUILD_CONFIG=Release -DDAL_GENERATOR=Ninja -P tests/installed-consumer/run.cmake
if errorlevel 1 exit /b 1
exit /b 0
