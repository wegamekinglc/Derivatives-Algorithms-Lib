@echo off
setlocal
call :run > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-installed-excel.log" 2>&1
set "DAL418_EXIT=%ERRORLEVEL%"
echo %DAL418_EXIT% > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-installed-excel-exit.txt"
exit /b %DAL418_EXIT%
:run
call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" -startdir=none -arch=x64 -host_arch=x64
if errorlevel 1 exit /b 1
cd /d "D:\multica-builds\dal418-eb7d672c679c-6372ede9\source"
set "CMAKE_BUILD_PARALLEL_LEVEL=6"
set "DAL_NUM_THREADS=4"
cmake "-DDAL_INSTALL_PREFIX=D:\multica-builds\dal418-eb7d672c679c-6372ede9\source\build\stage\Release-windows" "-DDAL_OPTIONAL_EXCEL_BINARY_DIR=D:\multica-builds\dal418-eb7d672c679c-6372ede9\installed-excel" -P tests/optional-excel/windows-installed.cmake
exit /b %ERRORLEVEL%
