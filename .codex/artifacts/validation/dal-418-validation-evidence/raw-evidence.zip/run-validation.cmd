@echo off
cd /d "D:\multica-builds\dal418-eb7d672c679c-6372ede9\source"
set "DAL_DIR=D:\multica-builds\dal418-eb7d672c679c-6372ede9\source"
set "NUMBER_OF_PROCESSORS=6"
set "DAL_NUM_THREADS=4"
call build_windows.bat > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-test_output.txt" 2>&1
set "DAL418_EXIT=%ERRORLEVEL%"
echo %DAL418_EXIT% > "D:\multica-builds\dal418-eb7d672c679c-6372ede9\windows-exit.txt"
exit /b %DAL418_EXIT%
